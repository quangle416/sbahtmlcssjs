Ecommerce Website

Website directed towards men who are looking for a professional style. Clothing items include suites, button up shirts, shoes, and accessories (ties and belts). Multiple links will be established to comb through different inventory items for purchase. There will be pages to sign up and login and to add items to a cart for purchase. 

Tools used:
HTML
CSS
Bootstrap
JavaScript

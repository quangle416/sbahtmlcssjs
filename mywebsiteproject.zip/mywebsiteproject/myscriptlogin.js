

const login = document.querySelector('.login');
login.onclick = (e) => {
    e.preventDefault();

    const emailAddress = document.getElementById("emailAddress").value;
    const passWord = document.getElementById("passWord").value;

    const Email = localStorage.getItem("Email");
    const Password = localStorage.getItem("Password");

    if( emailAddress == "" && passWord == ""){
        alert('error');
    }
    else
    {
        if(emailAddress == Email && passWord == Password){
           alert('Good job!');
        }else
        {
            alert('Something is wrong!');
        }
    };

};